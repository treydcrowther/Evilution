To build Evilution, run the command:

	mpic++ -o <filename> main.cpp

To run Evilution, run the command:

	mpiexec -n <number of processors> ./<location of build folder>/<filename>
	
Note: the number of processors must be square.