# Evilution

Spring 2022, Parallel Programming (CS 5500), Utah State Univeristy.

Final project by:

- Brian Callister
- Trey Crowther
- Kaden Hellewell

Instructions for building and running the project can be found in our [README.txt](docs/README.txt).